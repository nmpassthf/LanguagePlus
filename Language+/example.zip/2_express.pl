a = 1 + 2 + 3 + 4
b = a + 1
echo b
echo b + 1
