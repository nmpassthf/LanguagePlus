a = 1
_2 = a
_3 = _2

echo _3
